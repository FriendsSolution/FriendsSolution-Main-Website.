FRIENDS SOLUTION MAIN WEBSITE

This is the Friends Solution main website starter.

Included:
- Original Friends Solution master banner in assets/
- FriendsBook (FB)
- FriendsMessager (FM, green)
- FriendsTube (FT)
- FriendsChat (FC)
- FriendsMart (FM, orange)
- FriendsAgroMart (FAM)
- Company location: Bhubaneswar, Odisha, India
- Contact: friendssolution99@gmail.com
- Responsive mobile navigation

Branding:
- The supplied master banner is preserved and used as the main visual.
- No replacement or invented company logo is used in the header.
- The website address is not printed as page text.
- App links are intentionally not invented. Add official app URLs when supplied.

RENDER STATIC SITE:
- Build Command: leave blank
- Publish Directory: .
- Connect the GitHub repository containing the contents of this folder.
- Deploy as a Static Site.

GITHUB PAGES:
- Publish from the repository root on your chosen branch.
